package StaleModule;
our $VERSION = '1.0';
1;
