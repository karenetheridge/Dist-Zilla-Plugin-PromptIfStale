package Broken;

die 'oh noes!';
