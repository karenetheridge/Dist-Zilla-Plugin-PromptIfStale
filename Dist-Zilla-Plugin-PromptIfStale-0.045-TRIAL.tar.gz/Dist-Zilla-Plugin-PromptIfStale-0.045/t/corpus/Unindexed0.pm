package Unindexed0;
our $VERSION = '2.0';
die 'does not actually load!';
